#generating fibonacci series
n = int(input("Enter the value of 'n': "))
x = 0
y = 1
sum = 0
count = 1
print("Fibonacci Series: ", end = " ")
while(count <= n):
  print(sum, end = " ")
  count += 1
  x = y
  y = sum
  sum = x + y
