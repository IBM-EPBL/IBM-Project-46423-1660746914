#hariprasanth
m, n = 2, 19

# iterating each number in list
for num in range(m, n + 1):
	
	# checking condition
	if num % 2 != 0:
		print(num, end = " ")
